@echo off
setlocal DisableDelayedExpansion
set "XMR_PACKAGE_ROOT=%~dp0"
powershell.exe -NoProfile -Command "$ErrorActionPreference='Stop'; $root=[IO.Path]::GetFullPath($env:XMR_PACKAGE_ROOT); $exe=Join-Path $root 'xmrig.exe'; if(!(Test-Path -LiteralPath $exe)){throw 'xmrig.exe bulunamadi. Once ZIP dosyasini Tumu Ayikla ile cikar.'}; $startup=[Environment]::GetFolderPath('Startup'); $linkPath=Join-Path $startup 'XMRig CPU Madenciligi.lnk'; $shell=New-Object -ComObject WScript.Shell; if(Test-Path -LiteralPath $linkPath){ $lnk=$shell.CreateShortcut($linkPath); if($lnk.TargetPath -ne $exe){throw 'Baslangic kaydi baska bir XMRig klasorune ait. Windows Baslangic Uygulamalari ekranindan kontrol et.'}; Remove-Item -LiteralPath $linkPath -Force; Write-Host 'Otomatik baslangic kaldirildi.' } else { Write-Host 'Bu isimde baslangic kaydi yok.' }; $mine=@(Get-Process -Name xmrig -ErrorAction SilentlyContinue | Where-Object { try { $_.Path -eq $exe } catch { $false } }); foreach($p in $mine){ Stop-Process -Id $p.Id -ErrorAction Stop }; Write-Host 'Bu klasordeki madencilik durduruldu.'; "
if errorlevel 1 echo Islem tamamlanamadi. Yukaridaki hata mesajini kontrol et.
pause
