@echo off
setlocal DisableDelayedExpansion
set "XMR_PACKAGE_ROOT=%~dp0"
powershell.exe -NoProfile -Command "$ErrorActionPreference='Stop'; $root=[IO.Path]::GetFullPath($env:XMR_PACKAGE_ROOT); $exe=Join-Path $root 'xmrig.exe'; if(!(Test-Path -LiteralPath $exe)){throw 'xmrig.exe bulunamadi. Once ZIP dosyasini Tumu Ayikla ile cikar.'}; $mine=@(Get-Process -Name xmrig -ErrorAction SilentlyContinue | Where-Object { try { $_.Path -eq $exe } catch { $false } }); if($mine.Count -eq 0){ Start-Process -FilePath $exe -WorkingDirectory $root -WindowStyle Hidden -ArgumentList '--background --config=config.json --log-file=mining.log'; Write-Host 'XMRig arka planda baslatildi.' } else { Write-Host 'Bu klasordeki XMRig zaten calisiyor; ikinci kopya baslatilmadi.' }; "
if errorlevel 1 echo Islem tamamlanamadi. Yukaridaki hata mesajini kontrol et.
pause
