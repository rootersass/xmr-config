@echo off
setlocal DisableDelayedExpansion
set "XMR_PACKAGE_ROOT=%~dp0"
powershell.exe -NoProfile -Command "$ErrorActionPreference='Stop'; $root=[IO.Path]::GetFullPath($env:XMR_PACKAGE_ROOT); $exe=Join-Path $root 'xmrig.exe'; if(!(Test-Path -LiteralPath $exe)){throw 'xmrig.exe bulunamadi. Once ZIP dosyasini Tumu Ayikla ile cikar.'}; $mine=@(Get-Process -Name xmrig -ErrorAction SilentlyContinue | Where-Object { try { $_.Path -eq $exe } catch { $false } }); if($mine.Count){$mine | Select-Object Id,ProcessName,CPU,StartTime | Format-Table -AutoSize} else {Write-Host 'Bu klasordeki XMRig calismiyor.'}; $startup=[Environment]::GetFolderPath('Startup'); $linkPath=Join-Path $startup 'XMRig CPU Madenciligi.lnk'; if(Test-Path -LiteralPath $linkPath){$shell=New-Object -ComObject WScript.Shell; $lnk=$shell.CreateShortcut($linkPath); Write-Host ('Bu klasor icin otomatik baslangic: '+($lnk.TargetPath -eq $exe))} else {Write-Host 'Otomatik baslangic: kapali'}; $log=Join-Path $root 'mining.log'; if(Test-Path -LiteralPath $log){Write-Host 'Son log satirlari:'; Get-Content -LiteralPath $log -Tail 10}; "
if errorlevel 1 echo Islem tamamlanamadi. Yukaridaki hata mesajini kontrol et.
pause
