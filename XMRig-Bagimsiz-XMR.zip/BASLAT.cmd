@echo off
setlocal DisableDelayedExpansion
set "XMR_PACKAGE_ROOT=%~dp0"
powershell.exe -NoProfile -Command "$ErrorActionPreference='Stop'; $root=[IO.Path]::GetFullPath($env:XMR_PACKAGE_ROOT); $exe=Join-Path $root 'xmrig.exe'; if(!(Test-Path -LiteralPath $exe)){throw 'xmrig.exe bulunamadi. Once ZIP dosyasini Tumu Ayikla ile cikar.'}; $mine=@(Get-Process -Name xmrig -ErrorAction SilentlyContinue | Where-Object { try { $_.Path -eq $exe } catch { $false } }); if($mine.Count){Write-Host 'XMRig zaten arka planda veya baska pencerede calisiyor. DURUM ile kontrol et.'; exit 2}; "
if errorlevel 1 goto done
cd /d "%~dp0"
"%~dp0xmrig.exe" --config=config.json
:done
pause
