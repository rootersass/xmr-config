@echo off
setlocal DisableDelayedExpansion
set "XMR_PACKAGE_ROOT=%~dp0"
powershell.exe -NoProfile -Command "$ErrorActionPreference='Stop'; $root=[IO.Path]::GetFullPath($env:XMR_PACKAGE_ROOT); $exe=Join-Path $root 'xmrig.exe'; if(!(Test-Path -LiteralPath $exe)){throw 'xmrig.exe bulunamadi. Once ZIP dosyasini Tumu Ayikla ile cikar.'}; $mine=@(Get-Process -Name xmrig -ErrorAction SilentlyContinue | Where-Object { try { $_.Path -eq $exe } catch { $false } }); foreach($p in $mine){ Stop-Process -Id $p.Id -ErrorAction Stop }; Write-Host ('Durdurulan XMRig sayisi: '+$mine.Count); Write-Host 'Otomatik baslangic ayari degismedi. Tamamen kapatmak icin ACILISTAN-KALDIR dosyasini kullan.'; "
if errorlevel 1 echo Islem tamamlanamadi. Yukaridaki hata mesajini kontrol et.
pause
